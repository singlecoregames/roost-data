Source files for the hoatzin sprite. Frames 1-4 = flap cycle.
